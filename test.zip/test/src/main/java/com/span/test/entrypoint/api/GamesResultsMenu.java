package com.span.test.entrypoint.api;

public interface GamesResultsMenu {

    void getResultsFromConsole();
}
