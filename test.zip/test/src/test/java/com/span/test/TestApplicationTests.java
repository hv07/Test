package com.span.test;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestApplicationTests {

	//TODO

}
